/* =========================================================================
   Torc Deck Navigation
   ─────────────────────────────────────────────────────────────────────────
   Keyboard + click navigation, slide counter, progress bar, dark-slide
   detection. Imported by every deck via:
   <script src="/_shared/torc-deck-nav.js" defer></script>

   Markup contract: deck must have .deck > .slide elements, with optional
   data-dark="true" on dark slides, plus #prevBtn, #nextBtn, #cur, #tot,
   #progressBar elements.
   ========================================================================= */

(function () {
  document.addEventListener('DOMContentLoaded', function () {
    const slides = document.querySelectorAll('.slide');
    if (!slides.length) return;

    const total = slides.length;
    let current = 0;

    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const curDisplay = document.getElementById('cur');
    const totDisplay = document.getElementById('tot');
    const progressBar = document.getElementById('progressBar');

    if (totDisplay) totDisplay.textContent = String(total).padStart(2, '0');

    function show(idx) {
      slides.forEach((s, i) => s.classList.toggle('active', i === idx));
      if (curDisplay) curDisplay.textContent = String(idx + 1).padStart(2, '0');
      if (progressBar) progressBar.style.width = ((idx + 1) / total * 100) + '%';
      if (prevBtn) prevBtn.disabled = idx === 0;
      if (nextBtn) nextBtn.disabled = idx === total - 1;
      current = idx;

      // Toggle dark body class for nav inversion
      const isDark = slides[idx].dataset.dark === 'true';
      document.body.classList.toggle('is-dark', isDark);

      // Push slide index to URL hash for deep-linking
      if (history.replaceState) {
        history.replaceState(null, '', '#' + (idx + 1));
      }
    }

    function next() { if (current < total - 1) show(current + 1); }
    function prev() { if (current > 0) show(current - 1); }

    if (prevBtn) prevBtn.addEventListener('click', prev);
    if (nextBtn) nextBtn.addEventListener('click', next);

    document.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') {
        e.preventDefault(); next();
      }
      if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault(); prev();
      }
      if (e.key === 'Home') { show(0); }
      if (e.key === 'End') { show(total - 1); }
    });

    // Deep-link support: if URL has #N, start at slide N
    const hash = window.location.hash.replace('#', '');
    const startIdx = hash && !isNaN(hash) ? Math.max(0, Math.min(total - 1, parseInt(hash, 10) - 1)) : 0;
    show(startIdx);
  });
})();
